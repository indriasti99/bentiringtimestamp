package id.tvri.bentiring.timestamp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import id.tvri.bentiring.timestamp.ui.theme.TxBentiringTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TxBentiringTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    Text("TX BENTIRING TIMESTAMP - TVRI Bengkulu")
                }
            }
        }
    }
}