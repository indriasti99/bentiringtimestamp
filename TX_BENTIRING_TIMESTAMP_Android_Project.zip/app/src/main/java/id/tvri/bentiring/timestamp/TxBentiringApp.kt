package id.tvri.bentiring.timestamp
import android.app.Application
class TxBentiringApp : Application()