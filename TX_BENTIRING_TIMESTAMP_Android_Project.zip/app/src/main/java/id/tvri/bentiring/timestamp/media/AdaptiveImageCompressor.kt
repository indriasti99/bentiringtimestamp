package id.tvri.bentiring.timestamp.media

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

class AdaptiveImageCompressor(private val targetMaxBytes: Long = 300 * 1024L) {
    fun compress(sourceBitmap: Bitmap): ByteArray {
        var quality = 88
        val stream = ByteArrayOutputStream()
        sourceBitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
        var bytes = stream.toByteArray()

        while (bytes.size > targetMaxBytes && quality > 45) {
            quality -= 8
            val nextStream = ByteArrayOutputStream()
            sourceBitmap.compress(Bitmap.CompressFormat.JPEG, quality, nextStream)
            bytes = nextStream.toByteArray()
        }
        return bytes
    }
}